/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "stdlib.h"
#include <stdio.h>

#define ACCEL_ADDRESS 0x53
#define X0_REG 0x00
#define PWR_CTRL_REG 0x2D
#define PWR_MODE (1<<3)
uint8 rawData;

int main()
{
    UART_1_Start();
    UART_1_UartPutString("Hello Felix and Kristian\n");
    I2C_1_Start(); 
    I2C_1_I2CMasterClearStatus();
    char dataString[4]; 
    
    if(I2C_1_I2CMasterSendStart(ACCEL_ADDRESS, I2C_1_I2C_WRITE_XFER_MODE) == I2C_1_I2C_MSTR_NO_ERROR
        && I2C_1_I2CMasterWriteByte(PWR_CTRL_REG) == I2C_1_I2C_MSTR_NO_ERROR
        && I2C_1_I2CMasterWriteByte(PWR_MODE) == I2C_1_I2C_MSTR_NO_ERROR) 
    UART_1_UartPutString("Accelerometer initialized.\n");
    UART_1_UartPutString("10000 reads will now be performed.\nPlease wait.\n");
    
    I2C_1_I2CMasterSendStop();
    int errors = 0;
    int i;
    for(i = 0; i < 10000; i++){
        if (I2C_1_I2CMasterSendStart(ACCEL_ADDRESS, I2C_1_I2C_WRITE_XFER_MODE) == I2C_1_I2C_MSTR_NO_ERROR) /* Check if transfer completed without errors */
        { 
            if(I2C_1_I2CMasterWriteByte(X0_REG) == I2C_1_I2C_MSTR_NO_ERROR){
                if(I2C_1_I2CMasterSendRestart(ACCEL_ADDRESS, I2C_1_I2C_READ_XFER_MODE) == I2C_1_I2C_MSTR_NO_ERROR){
                    rawData = I2C_1_I2CMasterReadByte(I2C_1_I2C_NAK_DATA);
                    I2C_1_I2CMasterSendStop();
                    
                   
                  if(rawData != 0xE5)errors++;
                    
                }else{
                    I2C_1_I2CMasterSendStop(); /* Send Stop */
                    errors++;
                }
            } else {
                errors++;
            }
        }
        else
        {
            I2C_1_I2CMasterSendStop(); /* Send Stop */
            errors++;
        }
        
    }
    char errorString[32];
    sprintf(errorString,  "Finished reading.\nErrors: %d\n", errors);
    UART_1_UartPutString(errorString);
    while(1);
}

/* [] END OF FILE */
