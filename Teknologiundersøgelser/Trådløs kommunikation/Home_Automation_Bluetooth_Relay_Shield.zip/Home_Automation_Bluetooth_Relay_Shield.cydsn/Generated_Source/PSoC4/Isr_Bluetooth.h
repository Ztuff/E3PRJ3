/*******************************************************************************
* File Name: Isr_Bluetooth.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Isr_Bluetooth_H)
#define CY_ISR_Isr_Bluetooth_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Isr_Bluetooth_Start(void);
void Isr_Bluetooth_StartEx(cyisraddress address);
void Isr_Bluetooth_Stop(void);

CY_ISR_PROTO(Isr_Bluetooth_Interrupt);

void Isr_Bluetooth_SetVector(cyisraddress address);
cyisraddress Isr_Bluetooth_GetVector(void);

void Isr_Bluetooth_SetPriority(uint8 priority);
uint8 Isr_Bluetooth_GetPriority(void);

void Isr_Bluetooth_Enable(void);
uint8 Isr_Bluetooth_GetState(void);
void Isr_Bluetooth_Disable(void);

void Isr_Bluetooth_SetPending(void);
void Isr_Bluetooth_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Isr_Bluetooth ISR. */
#define Isr_Bluetooth_INTC_VECTOR            ((reg32 *) Isr_Bluetooth__INTC_VECT)

/* Address of the Isr_Bluetooth ISR priority. */
#define Isr_Bluetooth_INTC_PRIOR             ((reg32 *) Isr_Bluetooth__INTC_PRIOR_REG)

/* Priority of the Isr_Bluetooth interrupt. */
#define Isr_Bluetooth_INTC_PRIOR_NUMBER      Isr_Bluetooth__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Isr_Bluetooth interrupt. */
#define Isr_Bluetooth_INTC_SET_EN            ((reg32 *) Isr_Bluetooth__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Isr_Bluetooth interrupt. */
#define Isr_Bluetooth_INTC_CLR_EN            ((reg32 *) Isr_Bluetooth__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Isr_Bluetooth interrupt state to pending. */
#define Isr_Bluetooth_INTC_SET_PD            ((reg32 *) Isr_Bluetooth__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Isr_Bluetooth interrupt. */
#define Isr_Bluetooth_INTC_CLR_PD            ((reg32 *) Isr_Bluetooth__INTC_CLR_PD_REG)



#endif /* CY_ISR_Isr_Bluetooth_H */


/* [] END OF FILE */
