/* ========================================
 *
 * The following firmware was developed by Cypress Semiconductor
 * This work is licensed under a Creative Commons Attribution 3.0 Unported License.
 * 
 * http://creativecommons.org/licenses/by/3.0/deed.en_US
 * 
 * You are free to:
 * -To Share — to copy, distribute and transmit the work 
 * -To Remix — to adapt the work 
 * -To make commercial use of the work
 *
 * ========================================
 */
 
/* ========================================
 * CY8CKIT-042 Home Automation using Relaying Shield and Bluetooth Shield Demo
 * Updated 23/05/2013
 *
 * Features:
 * - Receives command from an Android cellphone
 * - Receives and sends data over Bluetooth
 * - 4 Appliances can be controlled using a cellphone via Bluetooth using Relay Shield
 
 ============================================ 
 */
 
#include <device.h>

#define DEVICE1_ON      'A'
#define DEVICE1_OFF     'B'

#define DEVICE2_ON      'C'
#define DEVICE2_OFF     'D'

#define DEVICE3_ON      'E'
#define DEVICE3_OFF     'F'

#define DEVICE4_ON      'G'
#define DEVICE4_OFF     'H'

void SetUpBluetooth(void);

extern uint8 ch, Rx_flag;


void main()
{   
    /* Enable the Global Interrupt */
    CyGlobalIntEnable;
    
    /* Start the UART component */
    UART_1_Start();
    
    /* Function to set up the bluetooth shield */
    SetUpBluetooth();

    while(1)
    {  
        /* To make the bluetooth enquirable again */   
        if(!Connect_Read())
		{	    
           UART_1_PutString("\r\n+INQ=1\r\n");
           while(!Connect_Read());
		   CyDelay(2000);   
		}
        
       /*  Checks whether data is being received on the bluetooth shield */
        if(Rx_flag)             
        {
           /* Reset the Flag */
		   Rx_flag=0;
        
           /* Change the status of Device 1 (say tubelight) based on the input from the user */ 
            if ( ch == DEVICE1_ON )
            {               
                Relay_1_Write(!Relay_1_ReadDataReg());                 
            }
           
           /* Change the status of Device 1 (say bulb) based on the input from the user */ 
            if ( ch == DEVICE2_ON )
            {
                   Relay_2_Write(!Relay_2_ReadDataReg());  
            }
           
           /* Change the status of Device 1 (say fan) based on the input from the user */
           if ( ch == DEVICE3_ON )
            {
                Relay_3_Write(!Relay_3_ReadDataReg()); 
            }
           
           /* Change the status of Device 4 (say AC) based on the input from the user */ 
            if ( ch == DEVICE4_ON )
            {
               Relay_4_Write(!Relay_4_ReadDataReg()); 
            }
        }
        
    }
}


/*******************************************************************************
* Function Name : SetUpBluetooth
********************************************************************************
*
* Summary:
*   Initializes the Bluetooth and makes it inquirable.
*
* Parameters:
*   None
*
* Return Value:
*   None
*
*******************************************************************************/

void SetUpBluetooth(void)
{
    
    UART_1_Start();
	
    /* Set the bluetooth work in slave mode */
    UART_1_PutString("\r\n+STWMOD=0\r\n");
	
	/* Set the bluetooth name as "Pioneer Kit" */
	UART_1_PutString("\r\n+STNA=Pioneer Kit\r\n");
	
	/* Permit Paired device to connect me */
	UART_1_PutString("\r\n+STOAUT=1\r\n"); 
	
	/* Auto-connection should be forbidden here */
	UART_1_PutString("\r\n+STAUTO=0\r\n");
	
    /* A delay of 2 seconds for auto connection*/
	CyDelay(2000);
	
	/* Make the slave bluetooth inquirable */
	UART_1_PutString("\r\n+INQ=1\r\n");
    CyDelay(2000);
 
 }

/* [] END OF FILE */
