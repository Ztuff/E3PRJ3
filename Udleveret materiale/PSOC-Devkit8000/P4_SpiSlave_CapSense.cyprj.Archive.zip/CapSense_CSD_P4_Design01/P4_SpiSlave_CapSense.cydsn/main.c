/*******************************************************************************
* File Name: main.c
*
* Version: 1.00
*
* Description:
*  The project explains the usage of CapSense CSD component. The 2 buttons and
*  linear sliders are used as sensing elements. 
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <device.h>

/* CapSense Slider resoluton is set to 127 (7 bits).
*  Since PWM has 16 bit resolution, slider position value should be shifted left
*  by 9 bits.
*/
#define SLIDER_POS_TO_COMPARE_SHIFT    (9u)

uint16 curPos, oldPos;

/* Function Prototypes */
CY_ISR_PROTO(isr_spi_rx);

/*******************************************************************************
* Function Name: main
********************************************************************************
* Summary:
*  Main function performs following functions:
*   1. Enable global interrupts.
*   2. Initialize CapSense CSD and Start the sensor scanning loop.
*   3. Process scanning results and display it on with LEDs.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
int main()
{
    /* Enable global interrupts */
    CyGlobalIntEnable;
    
    /* Init SPI Slave */
	SPIS_1_Start();
	SPIS_1_SetCustomInterruptHandler(isr_spi_rx);
	SPIS_1_SpiUartClearTxBuffer();

	/* Start ADC */
	 ADC_SAR_Seq_1_Start();
	 ADC_SAR_Seq_1_StartConvert();
	
	/* Start PWM and CapSense components */
    LED_CONTROL_Start();
    CapSense_CSD_Start();	

    /* Initialize baselines */ 
    CapSense_CSD_InitializeAllBaselines();

	/* Main Loop */
    while(1u)
    {
        /* Update all baselines */
        CapSense_CSD_UpdateEnabledBaselines();
        
   		/* Start scanning all enabled sensors */
    	CapSense_CSD_ScanEnabledWidgets();
    
        /* Wait for scanning to complete */
		while(CapSense_CSD_IsBusy() != 0);

		/* Display CapSense state using LEDs */
        CapSense_DisplayState();
    }
}

/*******************************************************************************
* Function Name: CapSense_DisplayState
********************************************************************************
* Summary:
*  Changes LEDs brightness by changing the duty cycle of PWM signals.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CapSense_DisplayState(void)
{
    /* Find Slider Position */
    curPos = CapSense_CSD_GetCentroidPos(CapSense_CSD_LINEARSLIDER0__LS);    
    
    /* Reset position */
    if(curPos == 0xFFFFu)
    {
        curPos = 0u;
    }
    /* Move bargraph */
    if (curPos != oldPos)
    {
        oldPos = curPos;
        /* Display Slider bargraph */
        if (curPos != 0u)
        {
            LED_CONTROL_WriteCompare((uint32)curPos << SLIDER_POS_TO_COMPARE_SHIFT);
        }        
    }
}


/*
 * SPI RX ISR
 * Dekoder SPI RX data og udfører kommando iht.
 */
CY_ISR(isr_spi_rx) {

	uint16 rxvalue;
	uint8 cmd;
	uint8 addr;
	uint8 rddata;
	TP_1_Write(1); // Til måling af ISR gennemløbstid
 
	rxvalue = SPIS_1_SpiUartReadRxData(); 
	
	/* Protocol - Write 8-bit: 
	 * |CMD|  ADDR  |    DATA    |
	 *  1 1 1      8 7          0
	 *	5 4 3
	 */

	/* Protocol - Read 16-bit: 
	 * |CMD|  ADDR  |  Not Used  |       |           DATA          |
	 *  1 1 1      8 7          0         1                       0
	 *	5 4 3                             5
	 */

	cmd = (rxvalue >> 14) & 0x3;  // cmd = rdvalue[15:14]
	addr = (rxvalue >> 8) & 0x3f; // addr = rdvalue[13:8]
	rddata = rxvalue & 0xff;      // data = rdvalue[7:0]

	/*
	 * Her switches på adressen. Kan der læses og skrives fra det pågældende
	 * register, implementeres dette under den pågældende adresse.
	 * I tilfælde af en read skal vi levere data tilbage. Dette skal gøres så hurtigt
	 * som muligt, da SPI masteren venter på data. Data antages at ligge klar til læsning. 
	 * Det eneste vi dermed skal gøre, er at kopiere variablen til SPI tx bufferen. 
	 * For at holde styr på hvad som udlæses, skal TX bufferen først cleares. 
	 * Devkit 8000 driveren forventer at kunne udlæse data efter 120 us (eller hvad som
	 * er specificeret i driveren).
	 */

	switch (addr) {
		case 0x1:
			if (cmd == 0x0) // Read 16-bit Slider Position
				SPIS_1_SpiUartClearTxBuffer();
				SPIS_1_SpiUartWriteTxData((int16)curPos);
			break;
		case 0x2:
			if (cmd == 0x0) // Read 16-bit Die Temperature
				SPIS_1_SpiUartClearTxBuffer();
				SPIS_1_SpiUartWriteTxData((int16)DieTemp_1_CountsTo_Celsius(ADC_SAR_Seq_1_GetResult16(0)));
			break;
		case 0x3:
			if (cmd == 0x0) // Read 16-bit Dummy Value
				SPIS_1_SpiUartClearTxBuffer();
				SPIS_1_SpiUartWriteTxData((int16)0xbeef);
			break;
		case 0x4:
			if (cmd == 0x1) // Write 8-bit to control LED color
				LED_CONTROL_WriteCompare(rddata<<8);
		default:
			break;
	}
	
	SPIS_1_ClearRxInterruptSource(SPIS_1_GetRxInterruptSource());
	TP_1_Write(0); // Til måling af ISR gennemløbstid
}


/* [] END OF FILE */
