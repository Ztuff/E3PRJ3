/*******************************************************************************
* File Name: SPIS_SPI_UART_INT.c
* Version 1.10
*
* Description:
*  This file provides the source code to the Interrupt Servive Routine for
*  the SCB Component in SPI and UART modes.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIS_PVT.h"
#include "SPIS_SPI_UART_PVT.h"


/*******************************************************************************
* Function Name: SPIS_SPI_UART_ISR
********************************************************************************
*
* Summary:
*  Handles Interrupt Service Routine for SCB SPI or UART modes.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(SPIS_SPI_UART_ISR)
{
    #if(SPIS_INTERNAL_RX_SW_BUFFER_CONST)
        uint32 locHead;
        uint32 dataRx;
    #endif /* (SPIS_INTERNAL_RX_SW_BUFFER_CONST) */

    #if(SPIS_INTERNAL_TX_SW_BUFFER_CONST)
        uint32 locTail;
    #endif /* (SPIS_INTERNAL_TX_SW_BUFFER_CONST) */

    if(NULL != SPIS_customIntrHandler)
    {
        SPIS_customIntrHandler(); /* Call customer routine if needed */
    }

    #if(SPIS_CHECK_SPI_WAKE_ENABLE)
    {
        /* Clear SPI wakeup source */
        SPIS_ClearSpiExtClkInterruptSource(SPIS_INTR_SPI_EC_WAKE_UP);
    }
    #endif

    #if(SPIS_CHECK_RX_SW_BUFFER)
    {
        /* Get data from RX FIFO */
        if(SPIS_CHECK_INTR_RX_MASKED(SPIS_INTR_RX_NOT_EMPTY))
        {
            while(0u != SPIS_GET_RX_FIFO_ENTRIES)
            {
                /* Get data from RX FIFO */
                dataRx = SPIS_RX_FIFO_RD_REG;

                /* Move local head index */
                locHead = (SPIS_rxBufferHead + 1u);

                /* Adjust local head index */
                if(SPIS_RX_BUFFER_SIZE == locHead)
                {
                    locHead = 0u;
                }

                if(locHead == SPIS_rxBufferTail)
                {
                    /* Overflow: through away new data */
                    SPIS_rxBufferOverflow = (uint8) SPIS_INTR_RX_OVERFLOW;
                }
                else
                {
                    /* Store received data */
                    SPIS_PutWordInRxBuffer(locHead, dataRx);

                    /* Move head index */
                    SPIS_rxBufferHead = locHead;
                }
            }

            SPIS_ClearRxInterruptSource(SPIS_INTR_RX_NOT_EMPTY);
        }
    }
    #endif


    #if(SPIS_CHECK_TX_SW_BUFFER)
    {
        if(SPIS_CHECK_INTR_TX_MASKED(SPIS_INTR_TX_NOT_FULL))
        {
            /* Put data into TX FIFO */
            while(SPIS_FIFO_SIZE != SPIS_GET_TX_FIFO_ENTRIES)
            {
                /* There is a data in TX software buffer */
                if(SPIS_txBufferHead != SPIS_txBufferTail)
                {
                    /* Mode local tail index */
                    locTail = (SPIS_txBufferTail + 1u);

                    /* Adjust local tail index */
                    if(SPIS_TX_BUFFER_SIZE == locTail)
                    {
                        locTail = 0u;
                    }

                    /* Put data into TX FIFO */
                    SPIS_TX_FIFO_WR_REG = SPIS_GetWordFromTxBuffer(locTail);

                    /* Mode tail index */
                    SPIS_txBufferTail = locTail;
                }
                else
                {
                    /* TX software buffer is EMPTY: end of transmitting */
                    SPIS_DISABLE_INTR_TX(SPIS_INTR_TX_NOT_FULL);
                    break;
                }
            }

            SPIS_ClearTxInterruptSource(SPIS_INTR_TX_NOT_FULL);
        }
    }
    #endif
}


/* [] END OF FILE */
