/*******************************************************************************
* File Name: TP1.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TP1_H) /* Pins TP1_H */
#define CY_PINS_TP1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "TP1_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    TP1_Write(uint8 value) ;
void    TP1_SetDriveMode(uint8 mode) ;
uint8   TP1_ReadDataReg(void) ;
uint8   TP1_Read(void) ;
uint8   TP1_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define TP1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define TP1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define TP1_DM_RES_UP          PIN_DM_RES_UP
#define TP1_DM_RES_DWN         PIN_DM_RES_DWN
#define TP1_DM_OD_LO           PIN_DM_OD_LO
#define TP1_DM_OD_HI           PIN_DM_OD_HI
#define TP1_DM_STRONG          PIN_DM_STRONG
#define TP1_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define TP1_MASK               TP1__MASK
#define TP1_SHIFT              TP1__SHIFT
#define TP1_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define TP1_PS                     (* (reg8 *) TP1__PS)
/* Data Register */
#define TP1_DR                     (* (reg8 *) TP1__DR)
/* Port Number */
#define TP1_PRT_NUM                (* (reg8 *) TP1__PRT) 
/* Connect to Analog Globals */                                                  
#define TP1_AG                     (* (reg8 *) TP1__AG)                       
/* Analog MUX bux enable */
#define TP1_AMUX                   (* (reg8 *) TP1__AMUX) 
/* Bidirectional Enable */                                                        
#define TP1_BIE                    (* (reg8 *) TP1__BIE)
/* Bit-mask for Aliased Register Access */
#define TP1_BIT_MASK               (* (reg8 *) TP1__BIT_MASK)
/* Bypass Enable */
#define TP1_BYP                    (* (reg8 *) TP1__BYP)
/* Port wide control signals */                                                   
#define TP1_CTL                    (* (reg8 *) TP1__CTL)
/* Drive Modes */
#define TP1_DM0                    (* (reg8 *) TP1__DM0) 
#define TP1_DM1                    (* (reg8 *) TP1__DM1)
#define TP1_DM2                    (* (reg8 *) TP1__DM2) 
/* Input Buffer Disable Override */
#define TP1_INP_DIS                (* (reg8 *) TP1__INP_DIS)
/* LCD Common or Segment Drive */
#define TP1_LCD_COM_SEG            (* (reg8 *) TP1__LCD_COM_SEG)
/* Enable Segment LCD */
#define TP1_LCD_EN                 (* (reg8 *) TP1__LCD_EN)
/* Slew Rate Control */
#define TP1_SLW                    (* (reg8 *) TP1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define TP1_PRTDSI__CAPS_SEL       (* (reg8 *) TP1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define TP1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) TP1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define TP1_PRTDSI__OE_SEL0        (* (reg8 *) TP1__PRTDSI__OE_SEL0) 
#define TP1_PRTDSI__OE_SEL1        (* (reg8 *) TP1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define TP1_PRTDSI__OUT_SEL0       (* (reg8 *) TP1__PRTDSI__OUT_SEL0) 
#define TP1_PRTDSI__OUT_SEL1       (* (reg8 *) TP1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define TP1_PRTDSI__SYNC_OUT       (* (reg8 *) TP1__PRTDSI__SYNC_OUT) 


#if defined(TP1__INTSTAT)  /* Interrupt Registers */

    #define TP1_INTSTAT                (* (reg8 *) TP1__INTSTAT)
    #define TP1_SNAP                   (* (reg8 *) TP1__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins TP1_H */


/* [] END OF FILE */
