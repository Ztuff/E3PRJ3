/*******************************************************************************
* File Name: ACC_Y.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "ACC_Y.h"


/*******************************************************************************
* Function Name: ACC_Y_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void ACC_Y_Write(uint8 value) 
{
    uint8 staticBits = (ACC_Y_DR & (uint8)(~ACC_Y_MASK));
    ACC_Y_DR = staticBits | ((uint8)(value << ACC_Y_SHIFT) & ACC_Y_MASK);
}


/*******************************************************************************
* Function Name: ACC_Y_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void ACC_Y_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(ACC_Y_0, mode);
}


/*******************************************************************************
* Function Name: ACC_Y_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro ACC_Y_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 ACC_Y_Read(void) 
{
    return (ACC_Y_PS & ACC_Y_MASK) >> ACC_Y_SHIFT;
}


/*******************************************************************************
* Function Name: ACC_Y_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 ACC_Y_ReadDataReg(void) 
{
    return (ACC_Y_DR & ACC_Y_MASK) >> ACC_Y_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(ACC_Y_INTSTAT) 

    /*******************************************************************************
    * Function Name: ACC_Y_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 ACC_Y_ClearInterrupt(void) 
    {
        return (ACC_Y_INTSTAT & ACC_Y_MASK) >> ACC_Y_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
