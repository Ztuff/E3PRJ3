/*******************************************************************************
* File Name: ACC_STModeISR.h
* Version 1.60
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__ACC_STModeISR_INTC_H__)
#define __ACC_STModeISR_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void ACC_STModeISR_Start(void);
void ACC_STModeISR_StartEx(cyisraddress address);
void ACC_STModeISR_Stop(void) ;

CY_ISR_PROTO(ACC_STModeISR_Interrupt);

void ACC_STModeISR_SetVector(cyisraddress address) ;
cyisraddress ACC_STModeISR_GetVector(void) ;

void ACC_STModeISR_SetPriority(uint8 priority) ;
uint8 ACC_STModeISR_GetPriority(void) ;

void ACC_STModeISR_Enable(void) ;
uint8 ACC_STModeISR_GetState(void) ;
void ACC_STModeISR_Disable(void) ;

void ACC_STModeISR_SetPending(void) ;
void ACC_STModeISR_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the ACC_STModeISR ISR. */
#define ACC_STModeISR_INTC_VECTOR            ((reg32 *) ACC_STModeISR__INTC_VECT)

/* Address of the ACC_STModeISR ISR priority. */
#define ACC_STModeISR_INTC_PRIOR             ((reg8 *) ACC_STModeISR__INTC_PRIOR_REG)

/* Priority of the ACC_STModeISR interrupt. */
#define ACC_STModeISR_INTC_PRIOR_NUMBER      ACC_STModeISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable ACC_STModeISR interrupt. */
#define ACC_STModeISR_INTC_SET_EN            ((reg32 *) ACC_STModeISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the ACC_STModeISR interrupt. */
#define ACC_STModeISR_INTC_CLR_EN            ((reg32 *) ACC_STModeISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the ACC_STModeISR interrupt state to pending. */
#define ACC_STModeISR_INTC_SET_PD            ((reg32 *) ACC_STModeISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the ACC_STModeISR interrupt. */
#define ACC_STModeISR_INTC_CLR_PD            ((reg32 *) ACC_STModeISR__INTC_CLR_PD_REG)



/* __ACC_STModeISR_INTC_H__ */
#endif
