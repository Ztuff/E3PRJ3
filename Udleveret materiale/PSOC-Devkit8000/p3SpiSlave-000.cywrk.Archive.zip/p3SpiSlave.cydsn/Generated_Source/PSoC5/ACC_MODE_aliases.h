/*******************************************************************************
* File Name: ACC_MODE.h  
* Version 1.70
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_ACC_MODE_ALIASES_H) /* Pins ACC_MODE_ALIASES_H */
#define CY_PINS_ACC_MODE_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"

/***************************************
*              Constants        
***************************************/
#define ACC_MODE_0		ACC_MODE__0__PC

#endif /* End Pins ACC_MODE_ALIASES_H */

/* [] END OF FILE */
