/*******************************************************************************
* File Name: ACC_Y.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ACC_Y_H) /* Pins ACC_Y_H */
#define CY_PINS_ACC_Y_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ACC_Y_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ACC_Y__PORT == 15 && ((ACC_Y__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    ACC_Y_Write(uint8 value) ;
void    ACC_Y_SetDriveMode(uint8 mode) ;
uint8   ACC_Y_ReadDataReg(void) ;
uint8   ACC_Y_Read(void) ;
uint8   ACC_Y_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define ACC_Y_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define ACC_Y_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define ACC_Y_DM_RES_UP          PIN_DM_RES_UP
#define ACC_Y_DM_RES_DWN         PIN_DM_RES_DWN
#define ACC_Y_DM_OD_LO           PIN_DM_OD_LO
#define ACC_Y_DM_OD_HI           PIN_DM_OD_HI
#define ACC_Y_DM_STRONG          PIN_DM_STRONG
#define ACC_Y_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define ACC_Y_MASK               ACC_Y__MASK
#define ACC_Y_SHIFT              ACC_Y__SHIFT
#define ACC_Y_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ACC_Y_PS                     (* (reg8 *) ACC_Y__PS)
/* Data Register */
#define ACC_Y_DR                     (* (reg8 *) ACC_Y__DR)
/* Port Number */
#define ACC_Y_PRT_NUM                (* (reg8 *) ACC_Y__PRT) 
/* Connect to Analog Globals */                                                  
#define ACC_Y_AG                     (* (reg8 *) ACC_Y__AG)                       
/* Analog MUX bux enable */
#define ACC_Y_AMUX                   (* (reg8 *) ACC_Y__AMUX) 
/* Bidirectional Enable */                                                        
#define ACC_Y_BIE                    (* (reg8 *) ACC_Y__BIE)
/* Bit-mask for Aliased Register Access */
#define ACC_Y_BIT_MASK               (* (reg8 *) ACC_Y__BIT_MASK)
/* Bypass Enable */
#define ACC_Y_BYP                    (* (reg8 *) ACC_Y__BYP)
/* Port wide control signals */                                                   
#define ACC_Y_CTL                    (* (reg8 *) ACC_Y__CTL)
/* Drive Modes */
#define ACC_Y_DM0                    (* (reg8 *) ACC_Y__DM0) 
#define ACC_Y_DM1                    (* (reg8 *) ACC_Y__DM1)
#define ACC_Y_DM2                    (* (reg8 *) ACC_Y__DM2) 
/* Input Buffer Disable Override */
#define ACC_Y_INP_DIS                (* (reg8 *) ACC_Y__INP_DIS)
/* LCD Common or Segment Drive */
#define ACC_Y_LCD_COM_SEG            (* (reg8 *) ACC_Y__LCD_COM_SEG)
/* Enable Segment LCD */
#define ACC_Y_LCD_EN                 (* (reg8 *) ACC_Y__LCD_EN)
/* Slew Rate Control */
#define ACC_Y_SLW                    (* (reg8 *) ACC_Y__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ACC_Y_PRTDSI__CAPS_SEL       (* (reg8 *) ACC_Y__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ACC_Y_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ACC_Y__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ACC_Y_PRTDSI__OE_SEL0        (* (reg8 *) ACC_Y__PRTDSI__OE_SEL0) 
#define ACC_Y_PRTDSI__OE_SEL1        (* (reg8 *) ACC_Y__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ACC_Y_PRTDSI__OUT_SEL0       (* (reg8 *) ACC_Y__PRTDSI__OUT_SEL0) 
#define ACC_Y_PRTDSI__OUT_SEL1       (* (reg8 *) ACC_Y__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ACC_Y_PRTDSI__SYNC_OUT       (* (reg8 *) ACC_Y__PRTDSI__SYNC_OUT) 


#if defined(ACC_Y__INTSTAT)  /* Interrupt Registers */

    #define ACC_Y_INTSTAT                (* (reg8 *) ACC_Y__INTSTAT)
    #define ACC_Y_SNAP                   (* (reg8 *) ACC_Y__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ACC_Y_H */


/* [] END OF FILE */
