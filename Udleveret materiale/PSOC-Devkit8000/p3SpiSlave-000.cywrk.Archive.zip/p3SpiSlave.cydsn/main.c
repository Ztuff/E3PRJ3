/* ========================================
 *
 * Copyright AU, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF AU.
 *
 * ========================================
*/
#include <device.h>

// Global Variables
uint8 acc_x, acc_y, acc_z;
uint8 DMA_1_Chan;
uint8 DMA_1_TD[3];

/* Function Prototypes */
void setLed(uint8 value);
CY_ISR_PROTO(isr_dma);
CY_ISR_PROTO(isr_spi_rx);

void main()
{
	/* Enable global interrupts. */
    CyGlobalIntEnable; 

    /* Init SPI Slave */
    SPIS_1_Start();
	SPIS_1_EnableRxInt();
	rx_isr_StartEx(isr_spi_rx);
	SPIS_1_ClearFIFO();
	SPIS_1_ClearTxBuffer();

    /* Init Accelerometer */
    ACC_ENABLE_Write(1);
    ACC_MODE_Write(1);
    ACC_STMODE_Write(0);

	/* DMA Configuration for DMA_1 */
	#define DMA_1_BYTES_PER_BURST 1
	#define DMA_1_REQUEST_PER_BURST 1
	#define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
	#define DMA_1_DST_BASE (CYDEV_SRAM_BASE)
	DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
	    HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
	DMA_1_TD[0] = CyDmaTdAllocate();
	DMA_1_TD[1] = CyDmaTdAllocate();
	DMA_1_TD[2] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_1_TD[0], 1, DMA_1_TD[1], DMA_1__TD_TERMOUT_EN);
	CyDmaTdSetConfiguration(DMA_1_TD[1], 1, DMA_1_TD[2], DMA_1__TD_TERMOUT_EN);
	CyDmaTdSetConfiguration(DMA_1_TD[2], 1, DMA_1_TD[0], DMA_1__TD_TERMOUT_EN);
	CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_DelSig_1_DEC_SAMP_PTR), LO16((uint32)&acc_x));
	CyDmaTdSetAddress(DMA_1_TD[1], LO16((uint32)ADC_DelSig_1_DEC_SAMP_PTR), LO16((uint32)&acc_y));
	CyDmaTdSetAddress(DMA_1_TD[2], LO16((uint32)ADC_DelSig_1_DEC_SAMP_PTR), LO16((uint32)&acc_z));
	CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
	CyDmaChEnable(DMA_1_Chan, 1);

    /* DMA ISR Init */
	dma_isr_StartEx(isr_dma);

	/* Init Analog Mux */
    AMux_1_Start();    

    /* Init Delta-Sigma ADC Module */
    ADC_DelSig_1_Init() ;   
    ADC_DelSig_1_Enable() ;
	/* Set ADC Coherency to LOW because of 8-bit ADC resolution */
	ADC_DelSig_1_SetCoherency(ADC_DelSig_1_COHER_LOW); 

	for(;;)
    {
		/* MAIN LOOP */
	}
}

/*
 * DMA ISR
 * Kaldes når DMA overførsel er færdig
 * Flytter input multiplexeren en pos frem
 * Synkroniserer DMA og Multiplexer efter hvert gennemløb
 */
CY_ISR(isr_dma) {
	static int ch = 0;
	
	if (ch==2) {
		// Her sikres at DMA1 TD0 udføres for kanal 0 osv
		// Dette sikrer synkronisme mellem de to
		CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]); 
		CyDmaChEnable(DMA_1_Chan, 1);
		ch=0;
	}
	else
		ch++;

	AMux_1_FastSelect(ch); // Skift til næste kanal
}

/*
 * Hjælpefunktion - Sætter LEDs
 */
void setLed(uint8 value) {
	LED_0_Write(value>>0 & 1);
	LED_1_Write(value>>1 & 1);
	LED_2_Write(value>>2 & 1);
	LED_3_Write(value>>3 & 1);
	LED_4_Write(value>>4 & 1);
	LED_5_Write(value>>5 & 1);
	LED_6_Write(value>>6 & 1);
	LED_7_Write(value>>7 & 1);
}

/*
 * SPI RX ISR
 * Dekoder SPI RX data og udfører kommando iht.
 */
CY_ISR(isr_spi_rx) {

	uint16 rxvalue;
	uint8 cmd;
	uint8 addr;
	uint8 rddata;
	TP1_Write(1); // Til måling af ISR gennemløbstid

	rxvalue = SPIS_1_ReadRxData(); 
	
	/* Protocol - Write 8-bit: 
	 * |CMD|  ADDR  |    DATA    |
	 *  1 1 1      8 7          0
	 *	5 4 3
	 */

	/* Protocol - Read 16-bit: 
	 * |CMD|  ADDR  |  Not Used  |       |           DATA          |
	 *  1 1 1      8 7          0         1                       0
	 *	5 4 3                             5
	 */

	cmd = (rxvalue >> 14) & 0x3;  // cmd = rdvalue[15:14]
	addr = (rxvalue >> 8) & 0x3f; // addr = rdvalue[13:8]
	rddata = rxvalue & 0xff;      // data = rdvalue[7:0]

	/*
	 * Her switches på adressen. Kan der læses og skrives fra det pågældende
	 * register, implementeres dette under den pågældende adresse.
	 * 
	 * I tilfælde af en read skal vi levere data tilbage. Dette skal gøres så hurtigt
	 * som muligt, da SPI masteren venter på data. Dette gøres ved at lade ADC'en anvende
	 * en DMA kanal til kontinuert at overføre data til en variabel. Det eneste vi dermed 
	 * skal gøre, er at kopiere variablen til SPI tx bufferen. For at holde styr på hvad 
	 * som udlæses, skal TX bufferen først cleares. Devkit 8000 driveren forventer at kunne 
	 * udlæse data efter 10 us.
	 */

	switch (addr) {
		case 0x1:
			if (cmd == 0x0) // Read 16-bit
			    setLed(~1);
				SPIS_1_ClearTxBuffer();
//				SPIS_1_WriteTxData(0x51); // Det tager noget tid inden vi når herned, målt med scope til ca 32 us
				SPIS_1_WriteTxData((int16)acc_x);
			break;
		case 0x2:
			if (cmd == 0x0) // Read 16-bit
			    setLed(~2);
				SPIS_1_ClearTxBuffer();
//				SPIS_1_WriteTxData(0x52);
				SPIS_1_WriteTxData((int16)acc_y);
			break;
		case 0x3:
			if (cmd == 0x0) // Read 16-bit
			    setLed(~3);
				SPIS_1_ClearTxBuffer();
//				SPIS_1_WriteTxData(0x53);
				SPIS_1_WriteTxData((int16)acc_z);
			break;
		case 0x4:
			if (cmd == 0x1) // Write 8-bit
				setLed(rddata);
		default:
			break;
	}
	
	TP1_Write(0); // Til måling af ISR gennemløbstid
}
/* [] END OF FILE */
